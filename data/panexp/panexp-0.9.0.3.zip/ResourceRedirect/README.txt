To set this up,
1. Go to the windhawk marketplace, search for "Resource Redirect" and install
2. Go to the mod settings, and under "Theme paths", add the path to this folder. It's heavily encouraged that you copy/move this folder somewhere where it stays.
3. Turn on at the very bottom "Redirect all loaded resources (experimental)"
4. Finally, go to the mod's Advanced tab, scroll down and turn on "Consider inclusion list patterns for critical system processes".