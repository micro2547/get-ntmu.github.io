// ==WindhawkMod==
// @id              cpl-classic-view
// @name            Control Panel Classic View
// @description     Hack to show "All Control Panel Items" as a folder
// @version         1.0
// @author          xalejandro
// @github          https://github.com/tetawaves
// @include         explorer.exe
// @compilerOptions -lshlwapi
// ==/WindhawkMod==

// ==WindhawkModSettings==
/*
- resid: 70
  $name: shell32.dll UIFILE resource id
  $description: UIFILE used in the classic view, icons will show in ViewHost element. -1 will use generic folder layout
*/
// ==/WindhawkModSettings==


#include <shlwapi.h>
#include <windhawk_utils.h>

#define CCommonLayoutDefinition_LayoutType(pThis) *((DWORD *)pThis + 5)

#define LAYOUT_CATEGORYICONSVIEW    4
#define LAYOUT_CLASSICVIEW          0x1337

UINT g_uResId = -1;

thread_local bool g_fCControlPanelFolder_CreateViewObject = false;
thread_local bool g_fCCommonLayoutDefinition_GetLayoutDefinition = false;

HRESULT (*CControlPanelFolder_CreateViewObject_orig)(void *, HWND, GUID, void **);
HRESULT CControlPanelFolder_CreateViewObject_hook(void *pThis, HWND hwnd, GUID guid, void **ppv)
{
    g_fCControlPanelFolder_CreateViewObject = true;
    HRESULT hr = CControlPanelFolder_CreateViewObject_orig(pThis, hwnd, guid, ppv);
    g_fCControlPanelFolder_CreateViewObject = false;
    return hr;
}

HRESULT (*CreateCommonFrame_orig)(void *, UINT, GUID, void **);
HRESULT CreateCommonFrame_hook(void * psf, UINT uLayoutType, GUID guid, void **ppv)
{
    if (g_fCControlPanelFolder_CreateViewObject && uLayoutType == LAYOUT_CATEGORYICONSVIEW)
    {
        uLayoutType = LAYOUT_CLASSICVIEW;
    }
    return CreateCommonFrame_orig(psf, uLayoutType, guid, ppv);
}

HRESULT (*CCommonLayoutDefinition_GetLayoutDefinition_orig)(void *, IUnknown **);
HRESULT CCommonLayoutDefinition_GetLayoutDefinition_hook(void *pThis, IUnknown **ppunk)
{
    g_fCCommonLayoutDefinition_GetLayoutDefinition = CCommonLayoutDefinition_LayoutType(pThis) == LAYOUT_CLASSICVIEW;
    HRESULT s = CCommonLayoutDefinition_GetLayoutDefinition_orig(pThis, ppunk);
    g_fCCommonLayoutDefinition_GetLayoutDefinition = false;
    return s;
}

using FindResourceW_t = decltype(&FindResourceW);
FindResourceW_t FindResourceW_orig;
HRSRC FindResourceW_hook(HMODULE hModule, LPCWSTR lpName, LPCWSTR lpType)
{
    if (g_fCCommonLayoutDefinition_GetLayoutDefinition)
    {
        if (IS_INTRESOURCE(lpName) && !IS_INTRESOURCE(lpType) && StrStrI(lpType, L"UIFILE") != nullptr)
        {
            if (g_uResId != (UINT)-1)
            {
                HRSRC resource = FindResourceW_orig(hModule, MAKEINTRESOURCEW(g_uResId), lpType);
                Wh_Log(L"%p", resource);
                if (resource) return resource;
            }
        }
    }

    return FindResourceW_orig(hModule, lpName, lpType);
}

BOOL Wh_ModInit() 
{
    Wh_Log(L"Init");

    g_uResId = Wh_GetIntSetting(L"resid");

    HMODULE kernelBaseModule = GetModuleHandle(L"kernelbase.dll");
    HMODULE kernel32Module = GetModuleHandle(L"kernel32.dll");

    auto setKernelFunctionHook = [kernelBaseModule, kernel32Module](
                                     PCSTR targetName, void* hookFunction,
                                     void** originalFunction) 
    {
        void* targetFunction = (void*)GetProcAddress(kernelBaseModule, targetName);
        if (!targetFunction) 
        {
            targetFunction = (void*)GetProcAddress(kernel32Module, targetName);
            if (!targetFunction) return FALSE;
        }

        return Wh_SetFunctionHook(targetFunction, hookFunction, originalFunction);
    };

    HMODULE hShell32 = LoadLibraryW(L"shell32.dll");

    if (!hShell32) 
    {
        Wh_Log(L"Failed to load shell32.dll");
        return FALSE;
    }

    WindhawkUtils::SYMBOL_HOOK shell32DllHooks[] = {
        {
            {
                L"public: virtual long __cdecl CControlPanelFolder::CreateViewObject(struct HWND__ *,struct _GUID const &,void * *)"
            },
            &CControlPanelFolder_CreateViewObject_orig,
            CControlPanelFolder_CreateViewObject_hook,
            false
        },
        {
            {
                L"long __cdecl CreateCommonFrame(struct IShellFolder *,enum tagLAYOUTTYPE,struct _GUID const &,void * *)"
            },
            &CreateCommonFrame_orig,
            CreateCommonFrame_hook,
            false
        },
        {
            {
                L"public: virtual long __cdecl CCommonLayoutDefinition::GetLayoutDefinition(struct IUnknown * *)"
            },
            &CCommonLayoutDefinition_GetLayoutDefinition_orig,
            CCommonLayoutDefinition_GetLayoutDefinition_hook,
            false
        }
    };

    if (!WindhawkUtils::HookSymbols(hShell32, shell32DllHooks, ARRAYSIZE(shell32DllHooks))) 
    {
        Wh_Log(L"Failed to hook shell32.dll");
        return FALSE;
    }

    setKernelFunctionHook("FindResourceW", (void*)FindResourceW_hook, (void**)&FindResourceW_orig);

    return TRUE;
}

void Wh_ModSettingsChanged() 
{
    g_uResId = Wh_GetIntSetting(L"resid");
}
